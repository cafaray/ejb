package edu.dgsca.spring;

public interface IPersona {
	public String getNombreCompleto();
	public String getRFC();
}
