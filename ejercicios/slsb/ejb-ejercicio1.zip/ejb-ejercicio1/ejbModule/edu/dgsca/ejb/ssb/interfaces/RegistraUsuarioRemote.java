package edu.dgsca.ejb.ssb.interfaces;

import javax.ejb.Remote;

@Remote
public interface RegistraUsuarioRemote extends IUsuario{}
